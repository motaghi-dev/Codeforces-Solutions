// Problem: Merge Equal Elements
// Contest: VK Cup 2018 - Wild-card Round 1 (unofficial unrated mirror)
// URL: https://codeforces.com/problemset/problem/2018/E

#include <bits/stdc++.h>
 
using namespace std;
 
 
 
int bs(int arr[], int l, int r, int x)
{
    if (r >= l)
    {
        int mid = l + (r - l) / 2;
 
        if (arr[mid] == x)
            return mid;
 
        if (arr[mid] > x)
            return bs(arr, l, mid - 1, x);
 
        return bs(arr, mid + 1, r, x);
    }
    return -1;
}
 
 
 
int main()
{
    ios::sync_with_stdio(false);
    int t;
    cin >> t;
    vector <int> a;
    for (int i = 0; i < t; i++)
    {
        int x;
        cin >> x;
        if (!a.empty())
        {
 
            while (x == a.back())
            {
                a.pop_back();
                x++;
            }
            a.push_back(x);
         //   cout << x << "*\n";
        }
        else
            a.push_back(x);
      //  cout << "\n";
    }
    cout << a.size() << "\n";
    for (int i = 0; i < a.size(); i++)
        cout << a[i] << " ";
    return 0;
}