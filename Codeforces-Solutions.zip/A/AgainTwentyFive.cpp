// Problem: Again Twenty Five!
// Contest: Experimental Educational Round: VolBIT Formulas Blitz
// URL: https://codeforces.com/problemset/problem/0/A

#include <iostream>
using namespace std;
 
int main()
{
    int64_t n,i,temp=0;
    cin >> n;
    cout << "25";
    return 0;
}