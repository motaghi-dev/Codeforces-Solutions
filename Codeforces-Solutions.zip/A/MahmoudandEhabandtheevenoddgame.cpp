// Problem: Mahmoud and Ehab and the even-odd game
// Contest: Codeforces Round 473 (Div. 2)
// URL: https://codeforces.com/problemset/problem/473/A

#include <iostream>
using namespace std;
 
int main()
{
    long long n;
    cin >> n;
    if (n%2 == 0)
        cout << "Mahmoud";
    else
 
        cout << "Ehab";
    return 0;
}